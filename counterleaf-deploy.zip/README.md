# Counterleaf — AI Budtender (Trial Demo)

A self-contained, front-end-only demo of an AI cannabis budtender: a conversational
survey, match-scored product **and brand** recommendations, side-by-side comparison,
and an evidence-based Q&A chat. All data is illustrative; each visitor's answers and
profile stay in their own browser (localStorage). No backend, no tracking.

## Run locally
Any static server works, e.g.:

```
python3 -m http.server 8000
```

Then open http://localhost:8000

## Publish on GitHub Pages
1. Create a repo named `counterleaf` and push this folder to `main`.
2. Repo **Settings → Pages → Build and deployment → Deploy from a branch → `main` / `(root)`**.
3. Live at `https://<username>.github.io/counterleaf/` in ~1 minute.

## Custom domain
Add your domain under **Settings → Pages → Custom domain**, then point DNS at GitHub
Pages per their instructions. HTTPS is issued automatically.

## Files
- `index.html` — the entire app (HTML/CSS/JS inline)
- `manifest.webmanifest` — installable web-app metadata
- `icon.svg` — app icon
- `sw.js` — service worker for offline use

_Educational use only. Not medical advice. 21+._
